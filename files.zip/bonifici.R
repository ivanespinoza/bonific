# loading files path, configFile, libraries 
setwd("C:/Users/u94132/Documents/iespinoza/bonifici")
source("libs.R")
source("configuration_file.R")

source("functions.R") #Functions to be load 
                        #public function: getMatrices()
#   Initiate dat as dataFrame to store all the movements in the query that are "positive" to the Study:
#   Study:  Get transfers made from someone to itself
dat=data.frame() 

#   Variable of months the script will take in consideration 
months <- c('GEN-2016','FEB-2016','MAR-2016','APR-2016','MAG-2016',
            'GIU-2016','LUG-2016','AGO-2016','SET-2016','OTT-2016',
            'NOV-2016','DIC-2016','GEN-2017','FEB-2017','MAR-2017',
            'APR-2017','MAG-2017','GIU-2017','LUG-2017','AGO-2017',
            'SET-2017')

#   Init the loop to get the matrices DAT, IMPORTO and NUMERO, that store all the "positive" data 
for (i in 1:length(months)){
  t0=Sys.time()
  tmp=getMatrices(months[i])
  if (i == 1){
    importo=tmp[1]
    numero=tmp[2]
    dat=as.data.frame(tmp[3])
  }
  else{
    importo=merge(x = importo, y = tmp[1], by = "IBAN", all = TRUE)
    importo[is.na(importo)]<-0
    
    numero=merge(x = numero, y = tmp[2], by = "IBAN", all = TRUE)
    numero[is.na(numero)]<-0
    
    d=as.data.frame(tmp[3])
    dat=rbind(dat,d)
  }
  print(paste(months[i],Sys.time()-t0,sep="---"))
}

#
# We save and store the dataFrames given
# saveRDS(importo, "files/importo.rds")
# saveRDS(numero, "files/numero.rds")
# saveRDS(dat, "files/data.rds")
#
# We reload the dataFrames stored 
# dat=readRDS("files/data.rds")
# importo=readRDS("files/importo.rds")
# numero=readRDS("files/numero.rds")
#
##
## Stadistics of the dataset with "positive" data to the Study 
s_importo=as.integer(dat$I_IMPORTO)
summary(s_importo)
Mode(s_importo)
sum(s_importo==500)

## Correlation between the sum by months in variables numero and importo
## create a dataFrame with the normalize values for graph correlation
sumS=as.data.frame(cbind(s=colSums(numero[-1]),i=colSums(importo[-1])))
cor(sumS)
sumNorma=cbind(normalize(sumS$s),normalize(sumS$i))

## WordCloud and statistics of the causale
## clean the field and print the wordcloud with minFrequency of 5000
text_corpus <- Corpus(VectorSource(dat$X_CAUSALE))
text_corpus <- tm_map(text_corpus, content_transformer(tolower))
text_corpus <- tm_map(text_corpus, removeWords, stopwords("it"))
#text_corpus <- tm_map(text_corpus, stemDocument)
text_corpus <- tm_map(text_corpus, removeNumbers)
#text_corpus <- tm_map(text_corpus, removePunctuation)
wordcloud(text_corpus, min.freq = 1400, random.order = F, colors = brewer.pal(4, "Dark2")) 

## Number of frequencies of every word in the causale
# take out special characters, double spaces of the string
dat_causale=str_replace_all(dat$X_CAUSALE, "[^[:alnum:]]", " ")
dat_causale=str_replace_all(dat_causalesale, "\\s+", " ")
# count the frequency 
freq=data.frame(table(unlist(strsplit(tolower(dat_causale), " "))), stringsAsFactors = FALSE)
# order the frequency
freq=freq[order(freq$Freq,  decreasing = TRUE),]

# take out stopWords of the count
freq=freq[-which(freq$Var1 %in% stopwords("it")),]
## Order by a high frequency and get the minors ones 
bfc=dat[grep("CONTO",str_to_upper(dat$X_CAUSALE)),]
freq_B=data.frame(table(unlist(strsplit(tolower(bfc$X_CAUSALE), " "))), stringsAsFactors = FALSE)
mut_n=sum(grepl("MUTUO",str_to_upper(bfc$X_CAUSALE)))
rat_n=sum(grepl("RATA",str_to_upper(bfc$X_CAUSALE)))
fon_n=sum(grepl(paste("\\b","FONDI","\\b", sep=""),str_to_upper(dat$X_CAUSALE)))

sum(grepl("MUTUO",str_to_upper(bfc$X_CAUSALE)) && grepl("RATA",str_to_upper(bfc$X_CAUSALE)))
count(str_to_upper(dat, 'X_CAUSALE'))
