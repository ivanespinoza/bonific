#17.40 17.43 18.04 18.10 18.25 18.40 18.45 19.05 19.10 19.25 19.40 19.45 20.00 20.02 20.23 20.43
dat=readRDS("files/data.rds")

# calculate the frequency of words and sort it by frequency
text_corpus <- Corpus(VectorSource(dat$X_CAUSALE))
text_corpus <- tm_map(text_corpus, content_transformer(tolower))
text_corpus <- tm_map(text_corpus, removeWords, stopwords("it"))
#text_corpus <- tm_map(text_corpus, stemDocument)
text_corpus <- tm_map(text_corpus, removeNumbers)
#text_corpus <- tm_map(text_corpus, removePunctuation)
summary(text_corpus)
dtm <- DocumentTermMatrix(text_corpus)
num=20
tf=as.data.frame(findFreqTerms(dtm, lowfreq = 1))
dtm$dimnames$Docs == "1"
findFreqTerms(dtm[dtm$dimnames$Docs == "2"], lowfreq = 5000)
t[which(!t[1:200,]$Var1 %in% tf$`findFreqTerms(dtm, lowfreq = 1)`),]
tf[4092,]

t[1:5,]
# ### 2
# ##
fe=c()
for (i in 1:length(f)){
  fe[i]=as.numeric(sum(grepl(paste("\\b",toupper(f[i]),"\\b", sep=""), toupper(dat$X_CAUSALE))))
}

freq=as.data.frame(cbind(f,fe))
summary(freq)
num=20
terms <- findFreqTerms(dtm)[1:num]
dtm[findFreqTerms(dtm)[1:num],] %>%
  as.matrix() %>%
  
rowSums(z)
dtm[1,]
rowSums()
getTransformations()
myDf <- data.frame(text = sapply(dtm, paste, collapse = " "), stringsAsFactors = FALSE)

library(qdap)

e=as.data.frame(dtm)

qview(dtm)
htruncdf(dat$X_CAUSALE)
tm_dat <- qdap_dat <- DATA[1:4, c(1, 4)]
rownames(dat$X_CAUSALE) <- paste("docs", 1:nrow(tm_dat))
tm_dat <- Corpus(DataframeSource(tm_dat[, 2, drop=FALSE]))




myTdm <- as.matrix(DocumentMatrix(dat$X_CAUSALE))
FreqMat <- data.frame(ST = rownames(myTdm), 
                      Freq = rowSums(myTdm), 
                      row.names = NULL)

dtm <-as.matrix(DocumentTermMatrix(text_corpus))
t=table(unlist(strsplit(tolower(dat$X_CAUSALE), " ")))
t=data.frame(table(unlist(strsplit(tolower(dat$X_CAUSALE), " "))), stringsAsFactors = FALSE)
nrow(t)
summary(t)


x  = df$company        #Company column data
x  = removeWords(t$Var1,stopwords("it"))

t1=t[which(t$Var1 %in% stopwords("it")),]
t=t[-which(t$Var1 %in% stopwords("it")),]
t[45010,]$Var1 %in% stopwords("it")
t=t[-45010,]
library(splitstackshape)
library(dplyr)
cSplit(df, "v1", sep = " ", direction = "long") %>%
  group_by(tolower(v1)) %>%
  summarise(Count = n(), 
            ScoreSum = sum(score))


