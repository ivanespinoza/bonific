months <- c('OTT-2017')
query_tot_bonifici_sql <- paste("select cl.c_ndg, cl.c_forma_giuridica, bon.c_conto_operazione, bon.c_filiale_conto_operazione, 
                                  replace(bon.i_importo, ',', '.') as i_importo, to_char(to_date(bon.d_esecuzione), 'dd-mm-yy') as d_esecuzione, 
                                bon.c_verso, bon.c_banca, bon.x_causale, 
                                upper(REGEXP_REPLACE(bon.s_intestazione_beneficiario,'[^a-zA-Z'']',' ')) as s_intestazione_beneficiario,
                                upper(REGEXP_REPLACE(bon.s_intestazione_ordinante,'[^a-zA-Z'']',' ')) as ordinante, bon.l_iban_ordinante, l_iban_beneficiario
                                from edb.bonifico bon 
                                join edb.cliente cl on
                                bon.c_ndg = cl.c_ndg and bon.c_banca = cl.c_banca
                                where cl.c_forma_giuridica in ('PF', 'CO')
                                and bon.c_banca = '05387' and bon.c_verso = 'P'
                                and bon.s_tipo_destinazione = 'ESTERNO'
                                and bon.s_stato not in ('RIFIUTATO','ANNULLATO')
                                and bon.d_esecuzione between TO_DATE('",months,"', 'MON-YYYY') AND LAST_DAY(TO_DATE('",months,"', 'MON-YYYY'))",sep = "")
query_tot_bonifici <-  dbGetQuery(con, query_tot_bonifici_sql)
q=as.data.frame(c(MONTH="OTT-2017", query_tot_bonifici))
head(q)
colnames(q[1])="MONTH"
colnames
q2=rbind(Q, q)
dat=readRDS("Bkps/1030/data.rds")
s_importo=as.integer(dat$I_IMPORTO)
summary(s_importo)
saveRDS(q2,"files/queryALL.rds")


# calculate the frequency of words and sort it by frequency
text_corpus <- Corpus(VectorSource(dat$X_CAUSALE))
text_corpus <- tm_map(text_corpus, content_transformer(tolower))
text_corpus <- tm_map(text_corpus, removeWords, stopwords("it"))
#text_corpus <- tm_map(text_corpus, stemDocument)
text_corpus <- tm_map(text_corpus, removeNumbers)
#text_corpus <- tm_map(text_corpus, removePunctuation)
summary(text_corpus)
dtm <- DocumentTermMatrix(text_corpus)
num=20
tf=as.data.frame(findFreqTerms(dtm, lowfreq = 1))
dtm$dimnames$Docs == "1"
findFreqTerms(dtm[dtm$dimnames$Docs == "2"], lowfreq = 5000)
t[which(!t[1:200,]$Var1 %in% tf$`findFreqTerms(dtm, lowfreq = 1)`),]
tf[4092,]

t[1:5,]
# ### 2
# ##
fe=c()
for (i in 1:length(f)){
  fe[i]=as.numeric(sum(grepl(paste("\\b",toupper(f[i]),"\\b", sep=""), toupper(dat$X_CAUSALE))))
}

freq=as.data.frame(cbind(f,fe))
summary(freq)
num=20
terms <- findFreqTerms(dtm)[1:num]
dtm[findFreqTerms(dtm)[1:num],] %>%
  as.matrix() %>%
  
rowSums(z)
dtm[1,]
rowSums()
getTransformations()
myDf <- data.frame(text = sapply(dtm, paste, collapse = " "), stringsAsFactors = FALSE)

library(qdap)

e=as.data.frame(dtm)

qview(dtm)
htruncdf(dat$X_CAUSALE)
tm_dat <- qdap_dat <- DATA[1:4, c(1, 4)]
rownames(dat$X_CAUSALE) <- paste("docs", 1:nrow(tm_dat))
tm_dat <- Corpus(DataframeSource(tm_dat[, 2, drop=FALSE]))




myTdm <- as.matrix(DocumentMatrix(dat$X_CAUSALE))
FreqMat <- data.frame(ST = rownames(myTdm), 
                      Freq = rowSums(myTdm), 
                      row.names = NULL)

dtm <-as.matrix(DocumentTermMatrix(text_corpus))
t=table(unlist(strsplit(tolower(dat$X_CAUSALE), " ")))
t=data.frame(table(unlist(strsplit(tolower(dat$X_CAUSALE), " "))), stringsAsFactors = FALSE)
nrow(t)
summary(t)


x  = df$company        #Company column data
x  = removeWords(t$Var1,stopwords("it"))

t1=t[which(t$Var1 %in% stopwords("it")),]
t=t[-which(t$Var1 %in% stopwords("it")),]
t[45010,]$Var1 %in% stopwords("it")
t=t[-45010,]
library(splitstackshape)
library(dplyr)
cSplit(df, "v1", sep = " ", direction = "long") %>%
  group_by(tolower(v1)) %>%
  summarise(Count = n(), 
            ScoreSum = sum(score))


