#library(rjson)
options(java.parameters = "-Xmx8048m")
memory.limit(size=10000000000024)
environment <- "PROD"
#drv <- JDBC("oracle.jdbc.OracleDriver",classPath="C:\\App\\oracle\\product\\11.2.0\\client_1\\jdbc\\lib\\ojdbc5.jar", " ")
drv <- JDBC("oracle.jdbc.OracleDriver",classPath="C:\\sqldeveloper\\jdbc\\lib\\ojdbc6.jar", " ")
#conneciton to TEST
if (environment == "TEST"){
     con <- dbConnect(drv, "jdbc:oracle:thin:jdbc:oracle:thin:@//oraractest-scanvip.gbbper.priv:1521/EDBTEST", "U80340_T", "U80340")
}else if (environment == "PROD"){
     con <- dbConnect(drv, "jdbc:oracle:thin:jdbc:oracle:thin:@//tns-edb.gbbper.priv:1521/EDB", "U80340", "U80340")
}

